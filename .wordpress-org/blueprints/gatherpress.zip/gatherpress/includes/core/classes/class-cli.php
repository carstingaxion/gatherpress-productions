<?php
/**
 * Class responsible for registering WP-CLI commands within GatherPress.
 *
 * This class registers WP-CLI commands specific to the GatherPress plugin,
 * allowing developers to interact with and manage plugin functionality via the command line.
 *
 * @package GatherPress\Core
 * @since 1.0.0
 */

namespace GatherPress\Core;

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit; // @codeCoverageIgnore

use GatherPress\Core\Commands\Event_Cli;
use GatherPress\Core\Commands\Settings_Cli;
use GatherPress\Core\Traits\Singleton;
use WP_CLI;

/**
 * Class Cli.
 *
 * The Cli class extends WP-CLI and provides custom WP-CLI commands
 * for interacting with and managing GatherPress functionality via the command line.
 *
 * @since 1.0.0
 */
class Cli {

	/**
	 * Enforces a single instance of this class.
	 */
	use Singleton;

	/**
	 * Constructor for the Cli class.
	 *
	 * Registers WP-CLI commands for GatherPress if WP-CLI is present.
	 *
	 * @since 1.0.0
	 */
	protected function __construct() {
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			WP_CLI::add_command( 'gatherpress event', Event_Cli::class );
			WP_CLI::add_command( 'gatherpress settings', Settings_Cli::class );
		}
	}
}
